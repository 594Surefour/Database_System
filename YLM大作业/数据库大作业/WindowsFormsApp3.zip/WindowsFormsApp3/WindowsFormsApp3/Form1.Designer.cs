﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.TextBox();
            this.userpwd = new System.Windows.Forms.TextBox();
            this.identity = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.login = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.fare = new System.Windows.Forms.CheckBox();
            this.request = new System.Windows.Forms.CheckBox();
            this.job = new System.Windows.Forms.CheckBox();
            this.register_qiu = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.register_yong = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.register_guan = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.identity.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.register_qiu.SuspendLayout();
            this.register_yong.SuspendLayout();
            this.register_guan.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "用户名";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "密码";
            // 
            // username
            // 
            this.username.Location = new System.Drawing.Point(105, 6);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(100, 25);
            this.username.TabIndex = 2;
            // 
            // userpwd
            // 
            this.userpwd.Location = new System.Drawing.Point(105, 46);
            this.userpwd.Name = "userpwd";
            this.userpwd.PasswordChar = '*';
            this.userpwd.Size = new System.Drawing.Size(100, 25);
            this.userpwd.TabIndex = 3;
            // 
            // identity
            // 
            this.identity.Controls.Add(this.radioButton3);
            this.identity.Controls.Add(this.radioButton2);
            this.identity.Controls.Add(this.radioButton1);
            this.identity.Location = new System.Drawing.Point(15, 95);
            this.identity.Name = "identity";
            this.identity.Size = new System.Drawing.Size(200, 100);
            this.identity.TabIndex = 4;
            this.identity.TabStop = false;
            this.identity.Text = "身份";
            this.identity.Enter += new System.EventHandler(this.identity_Enter);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(17, 66);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(73, 19);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.Text = "管理员";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(106, 21);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(88, 19);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "用人单位";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(17, 21);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(73, 19);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "求职者";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // login
            // 
            this.login.Location = new System.Drawing.Point(243, 30);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(98, 84);
            this.login.TabIndex = 3;
            this.login.Text = "登录";
            this.login.UseVisualStyleBackColor = true;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(373, 30);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 84);
            this.button2.TabIndex = 4;
            this.button2.Text = "退出";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.fare);
            this.groupBox1.Controls.Add(this.request);
            this.groupBox1.Controls.Add(this.job);
            this.groupBox1.Location = new System.Drawing.Point(15, 230);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(475, 104);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "权限";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // fare
            // 
            this.fare.AutoSize = true;
            this.fare.Enabled = false;
            this.fare.Location = new System.Drawing.Point(330, 48);
            this.fare.Name = "fare";
            this.fare.Size = new System.Drawing.Size(119, 19);
            this.fare.TabIndex = 2;
            this.fare.Text = "费用信息管理";
            this.fare.UseVisualStyleBackColor = true;
            // 
            // request
            // 
            this.request.AutoSize = true;
            this.request.Enabled = false;
            this.request.Location = new System.Drawing.Point(183, 48);
            this.request.Name = "request";
            this.request.Size = new System.Drawing.Size(119, 19);
            this.request.TabIndex = 1;
            this.request.Text = "求职信息管理";
            this.request.UseVisualStyleBackColor = true;
            // 
            // job
            // 
            this.job.AutoSize = true;
            this.job.Checked = true;
            this.job.CheckState = System.Windows.Forms.CheckState.Checked;
            this.job.Enabled = false;
            this.job.Location = new System.Drawing.Point(27, 48);
            this.job.Name = "job";
            this.job.Size = new System.Drawing.Size(119, 19);
            this.job.TabIndex = 0;
            this.job.Text = "职业信息管理";
            this.job.UseVisualStyleBackColor = true;
            // 
            // register_qiu
            // 
            this.register_qiu.Controls.Add(this.button1);
            this.register_qiu.Controls.Add(this.textBox2);
            this.register_qiu.Controls.Add(this.textBox1);
            this.register_qiu.Controls.Add(this.label4);
            this.register_qiu.Controls.Add(this.label3);
            this.register_qiu.Location = new System.Drawing.Point(15, 340);
            this.register_qiu.Name = "register_qiu";
            this.register_qiu.Size = new System.Drawing.Size(475, 98);
            this.register_qiu.TabIndex = 6;
            this.register_qiu.TabStop = false;
            this.register_qiu.Text = "求职者注册";
            this.register_qiu.Visible = false;
            this.register_qiu.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(341, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 57);
            this.button1.TabIndex = 4;
            this.button1.Text = "注册";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(157, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 25);
            this.textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(157, 33);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 25);
            this.textBox1.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "注册密码";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "注册用户名";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(221, 124);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 60);
            this.button3.TabIndex = 7;
            this.button3.Text = "求职者注册";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(316, 124);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 60);
            this.button4.TabIndex = 8;
            this.button4.Text = "用人单位注册";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(415, 124);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 60);
            this.button5.TabIndex = 9;
            this.button5.Text = "管理员注册";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // register_yong
            // 
            this.register_yong.Controls.Add(this.button6);
            this.register_yong.Controls.Add(this.textBox4);
            this.register_yong.Controls.Add(this.textBox3);
            this.register_yong.Controls.Add(this.label6);
            this.register_yong.Controls.Add(this.label5);
            this.register_yong.Location = new System.Drawing.Point(15, 340);
            this.register_yong.Name = "register_yong";
            this.register_yong.Size = new System.Drawing.Size(475, 98);
            this.register_yong.TabIndex = 10;
            this.register_yong.TabStop = false;
            this.register_yong.Text = "用人单位注册";
            this.register_yong.Visible = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(341, 34);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 54);
            this.button6.TabIndex = 4;
            this.button6.Text = "注册";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(155, 67);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 25);
            this.textBox4.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(155, 31);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 25);
            this.textBox3.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "注册密码";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "注册用户名";
            // 
            // register_guan
            // 
            this.register_guan.Controls.Add(this.button7);
            this.register_guan.Controls.Add(this.textBox6);
            this.register_guan.Controls.Add(this.textBox5);
            this.register_guan.Controls.Add(this.label8);
            this.register_guan.Controls.Add(this.label7);
            this.register_guan.Location = new System.Drawing.Point(15, 340);
            this.register_guan.Name = "register_guan";
            this.register_guan.Size = new System.Drawing.Size(475, 98);
            this.register_guan.TabIndex = 11;
            this.register_guan.TabStop = false;
            this.register_guan.Text = "管理员注册";
            this.register_guan.Visible = false;
            this.register_guan.Enter += new System.EventHandler(this.register_guan_Enter);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(358, 23);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 62);
            this.button7.TabIndex = 4;
            this.button7.Text = "注册";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(155, 66);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 25);
            this.textBox6.TabIndex = 3;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(155, 29);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 25);
            this.textBox5.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(57, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "注册密码";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "注册用户名";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 450);
            this.Controls.Add(this.register_guan);
            this.Controls.Add(this.register_yong);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.register_qiu);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.login);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.identity);
            this.Controls.Add(this.userpwd);
            this.Controls.Add(this.username);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.identity.ResumeLayout(false);
            this.identity.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.register_qiu.ResumeLayout(false);
            this.register_qiu.PerformLayout();
            this.register_yong.ResumeLayout(false);
            this.register_yong.PerformLayout();
            this.register_guan.ResumeLayout(false);
            this.register_guan.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.TextBox userpwd;
        private System.Windows.Forms.GroupBox identity;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button login;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox fare;
        private System.Windows.Forms.CheckBox request;
        private System.Windows.Forms.CheckBox job;
        private System.Windows.Forms.GroupBox register_qiu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox register_yong;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox register_guan;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}

