﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Collections;
using System.Linq;


namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        Hashtable a = new Hashtable(20);
        Hashtable b = new Hashtable(20);
        Hashtable c = new Hashtable(20);
        public static string user_pwd, user_identity, user_name;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            job.Checked = true;
            request.Checked = fare.Checked = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            job.Checked = request.Checked = true;
            fare.Checked = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            job.Checked = request.Checked =fare.Checked= true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            if (a.ContainsKey(textBox1.Text))
            {
                MessageBox.Show("用户名已存在，请直接登录！");
            }
            else
            {
                a.Add(textBox1.Text, textBox2.Text);
                MessageBox.Show("注册成功");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

                register_qiu.Visible = true;
                register_yong.Visible = register_guan.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (b.ContainsKey(textBox3.Text))
            {
                MessageBox.Show("用户名已存在，请直接登录！");
            }
            else
            {
                b.Add(textBox3.Text, textBox4.Text);
                MessageBox.Show("注册成功");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (c.ContainsKey(textBox5.Text))
            {
                MessageBox.Show("用户名已存在，请直接登录！");
            }
            else
            {
                c.Add(textBox5.Text, textBox6.Text);
                MessageBox.Show("注册成功");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
                register_yong.Visible = true;
                register_qiu.Visible = register_guan.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (username.Text=="3" && userpwd.Text=="admin")
            {
                register_guan.Visible = true;
                register_qiu.Visible = register_yong.Visible = false;
            }
            else
            {
                register_qiu.Visible = register_yong.Visible = register_guan.Visible= false;
                MessageBox.Show("请正确输入身份信息，验证身份后进入注册页面！");
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void identity_Enter(object sender, EventArgs e)
        {

        }

        private void register_guan_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            a.Add("1", "123456");
            b.Add("2", "yongrendanwei");
            c.Add("3", "admin");
        }
       
        private void login_Click(object sender, EventArgs e)
        {
            user_name = username.Text;
            user_pwd = userpwd.Text;
            user_identity = "";
            foreach (Control ctl in identity.Controls)
            {
                RadioButton rad = (RadioButton)ctl;
                if (rad.Checked)
                {
                    user_identity = rad.Text;
                }
            }
            mainmenu mainmenu = new mainmenu();
          
            
            switch (user_identity)
            {
                case "管理员":
                    {
                        if (c.ContainsKey(user_name) && c.ContainsValue(user_pwd))
                        {
                            mainmenu.Show();
                        }
                        else MessageBox.Show("用户名或密码或身份选择不正确！请重新输入");
                        break;
                    }

                case "用人单位":
                    {
                        if (b.ContainsKey(user_name) && b.ContainsValue(user_pwd))
                        {
                            mainmenu.Show();
                            mainmenu.费用信息管理ToolStripMenuItem.Visible = false;
                            
                        }
                        else MessageBox.Show("用户名或密码或身份选择不正确！请重新输入");
                        break;

                    }
                case "求职者":
                    {
                        if (a.ContainsKey(user_name) && a.ContainsValue(user_pwd))
                        {
                            mainmenu.Show();
                            mainmenu.费用信息管理ToolStripMenuItem.Visible = false;
                            mainmenu.求职信息管理ToolStripMenuItem.Visible = false;
                        }
                        else MessageBox.Show("用户名或密码或身份选择不正确！请重新输入");
                        break;
                    }
            }


          

        }
    }
}
