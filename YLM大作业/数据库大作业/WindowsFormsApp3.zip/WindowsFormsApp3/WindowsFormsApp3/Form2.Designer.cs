﻿namespace WindowsFormsApp3
{
    partial class mainmenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.职业信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.职业信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.用人单位ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.职业分类ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一键查询工作岗位余量ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.求职信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.求职者ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.输出每个应聘成功的求职者及供职的公司ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.费用信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.单位收费ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.介绍人员ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.职业介绍信息管理系统DataSet = new WindowsFormsApp3.职业介绍信息管理系统DataSet();
            this.职业信息BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.职业信息TableAdapter = new WindowsFormsApp3.职业介绍信息管理系统DataSetTableAdapters.职业信息TableAdapter();
            this.tableAdapterManager = new WindowsFormsApp3.职业介绍信息管理系统DataSetTableAdapters.TableAdapterManager();
            this.button2 = new System.Windows.Forms.Button();
            this.职业介绍信息管理系统DataSet7 = new WindowsFormsApp3.职业介绍信息管理系统DataSet7();
            this.view1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view1TableAdapter = new WindowsFormsApp3.职业介绍信息管理系统DataSet7TableAdapters.view1TableAdapter();
            this.tableAdapterManager1 = new WindowsFormsApp3.职业介绍信息管理系统DataSet7TableAdapters.TableAdapterManager();
            this.view1_remain = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.职业介绍信息管理系统DataSet8 = new WindowsFormsApp3.职业介绍信息管理系统DataSet8();
            this.view2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view2TableAdapter = new WindowsFormsApp3.职业介绍信息管理系统DataSet8TableAdapters.view2TableAdapter();
            this.tableAdapterManager2 = new WindowsFormsApp3.职业介绍信息管理系统DataSet8TableAdapters.TableAdapterManager();
            this.view_moneyfromc = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.职业介绍信息管理系统DataSet9 = new WindowsFormsApp3.职业介绍信息管理系统DataSet9();
            this.view3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view3TableAdapter = new WindowsFormsApp3.职业介绍信息管理系统DataSet9TableAdapters.view3TableAdapter();
            this.tableAdapterManager3 = new WindowsFormsApp3.职业介绍信息管理系统DataSet9TableAdapters.TableAdapterManager();
            this.view_moneyfromb = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.职业介绍信息管理系统DataSet10 = new WindowsFormsApp3.职业介绍信息管理系统DataSet10();
            this.view4BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view4TableAdapter = new WindowsFormsApp3.职业介绍信息管理系统DataSet10TableAdapters.view4TableAdapter();
            this.tableAdapterManager4 = new WindowsFormsApp3.职业介绍信息管理系统DataSet10TableAdapters.TableAdapterManager();
            this.view_company = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业信息BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view1_remain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_moneyfromc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_moneyfromb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view4BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_company)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.职业信息管理ToolStripMenuItem,
            this.求职信息管理ToolStripMenuItem,
            this.费用信息管理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(686, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 职业信息管理ToolStripMenuItem
            // 
            this.职业信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.职业信息ToolStripMenuItem,
            this.用人单位ToolStripMenuItem,
            this.职业分类ToolStripMenuItem,
            this.一键查询工作岗位余量ToolStripMenuItem});
            this.职业信息管理ToolStripMenuItem.Name = "职业信息管理ToolStripMenuItem";
            this.职业信息管理ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.职业信息管理ToolStripMenuItem.Text = "职业信息管理";
            this.职业信息管理ToolStripMenuItem.Click += new System.EventHandler(this.职业信息管理ToolStripMenuItem_Click);
            // 
            // 职业信息ToolStripMenuItem
            // 
            this.职业信息ToolStripMenuItem.Name = "职业信息ToolStripMenuItem";
            this.职业信息ToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.职业信息ToolStripMenuItem.Text = "职业信息";
            this.职业信息ToolStripMenuItem.Click += new System.EventHandler(this.职业信息ToolStripMenuItem_Click);
            // 
            // 用人单位ToolStripMenuItem
            // 
            this.用人单位ToolStripMenuItem.Name = "用人单位ToolStripMenuItem";
            this.用人单位ToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.用人单位ToolStripMenuItem.Text = "用人单位";
            this.用人单位ToolStripMenuItem.Click += new System.EventHandler(this.用人单位ToolStripMenuItem_Click);
            // 
            // 职业分类ToolStripMenuItem
            // 
            this.职业分类ToolStripMenuItem.Name = "职业分类ToolStripMenuItem";
            this.职业分类ToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.职业分类ToolStripMenuItem.Text = "职业分类";
            this.职业分类ToolStripMenuItem.Click += new System.EventHandler(this.职业分类ToolStripMenuItem_Click);
            // 
            // 一键查询工作岗位余量ToolStripMenuItem
            // 
            this.一键查询工作岗位余量ToolStripMenuItem.Name = "一键查询工作岗位余量ToolStripMenuItem";
            this.一键查询工作岗位余量ToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.一键查询工作岗位余量ToolStripMenuItem.Text = "一键查询工作岗位余量";
            this.一键查询工作岗位余量ToolStripMenuItem.Click += new System.EventHandler(this.一键查询工作岗位余量ToolStripMenuItem_Click);
            // 
            // 求职信息管理ToolStripMenuItem
            // 
            this.求职信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.求职者ToolStripMenuItem,
            this.输出每个应聘成功的求职者及供职的公司ToolStripMenuItem});
            this.求职信息管理ToolStripMenuItem.Name = "求职信息管理ToolStripMenuItem";
            this.求职信息管理ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.求职信息管理ToolStripMenuItem.Text = "求职信息管理";
            this.求职信息管理ToolStripMenuItem.Click += new System.EventHandler(this.求职信息管理ToolStripMenuItem_Click);
            // 
            // 求职者ToolStripMenuItem
            // 
            this.求职者ToolStripMenuItem.Name = "求职者ToolStripMenuItem";
            this.求职者ToolStripMenuItem.Size = new System.Drawing.Size(354, 26);
            this.求职者ToolStripMenuItem.Text = "求职者";
            this.求职者ToolStripMenuItem.Click += new System.EventHandler(this.求职者ToolStripMenuItem_Click);
            // 
            // 输出每个应聘成功的求职者及供职的公司ToolStripMenuItem
            // 
            this.输出每个应聘成功的求职者及供职的公司ToolStripMenuItem.Name = "输出每个应聘成功的求职者及供职的公司ToolStripMenuItem";
            this.输出每个应聘成功的求职者及供职的公司ToolStripMenuItem.Size = new System.Drawing.Size(354, 26);
            this.输出每个应聘成功的求职者及供职的公司ToolStripMenuItem.Text = "输出每个应聘成功的求职者及供职的公司";
            this.输出每个应聘成功的求职者及供职的公司ToolStripMenuItem.Click += new System.EventHandler(this.输出每个应聘成功的求职者及供职的公司ToolStripMenuItem_Click);
            // 
            // 费用信息管理ToolStripMenuItem
            // 
            this.费用信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.单位收费ToolStripMenuItem,
            this.介绍人员ToolStripMenuItem,
            this.一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem,
            this.一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem});
            this.费用信息管理ToolStripMenuItem.Name = "费用信息管理ToolStripMenuItem";
            this.费用信息管理ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.费用信息管理ToolStripMenuItem.Text = "费用信息管理";
            this.费用信息管理ToolStripMenuItem.Click += new System.EventHandler(this.费用信息管理ToolStripMenuItem_Click);
            // 
            // 单位收费ToolStripMenuItem
            // 
            this.单位收费ToolStripMenuItem.Name = "单位收费ToolStripMenuItem";
            this.单位收费ToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.单位收费ToolStripMenuItem.Text = "单位收费";
            this.单位收费ToolStripMenuItem.Click += new System.EventHandler(this.单位收费ToolStripMenuItem_Click);
            // 
            // 介绍人员ToolStripMenuItem
            // 
            this.介绍人员ToolStripMenuItem.Name = "介绍人员ToolStripMenuItem";
            this.介绍人员ToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.介绍人员ToolStripMenuItem.Text = "介绍人员";
            this.介绍人员ToolStripMenuItem.Click += new System.EventHandler(this.介绍人员ToolStripMenuItem_Click);
            // 
            // 一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem
            // 
            this.一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem.Name = "一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem";
            this.一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem.Text = "一键查询中介人员从求职者处取得的中介费收入";
            this.一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem.Click += new System.EventHandler(this.一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem_Click);
            // 
            // 一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem
            // 
            this.一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem.Name = "一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem";
            this.一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem.Text = "一键查询中介人员从企业处取得的中介费收入";
            this.一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem.Click += new System.EventHandler(this.一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem_Click);
            // 
            // 职业介绍信息管理系统DataSet
            // 
            this.职业介绍信息管理系统DataSet.DataSetName = "职业介绍信息管理系统DataSet";
            this.职业介绍信息管理系统DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 职业信息BindingSource
            // 
            this.职业信息BindingSource.DataMember = "职业信息";
            this.职业信息BindingSource.DataSource = this.职业介绍信息管理系统DataSet;
            // 
            // 职业信息TableAdapter
            // 
            this.职业信息TableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp3.职业介绍信息管理系统DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.职业信息TableAdapter = this.职业信息TableAdapter;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(556, 142);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 79);
            this.button2.TabIndex = 2;
            this.button2.Text = "退出";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // 职业介绍信息管理系统DataSet7
            // 
            this.职业介绍信息管理系统DataSet7.DataSetName = "职业介绍信息管理系统DataSet7";
            this.职业介绍信息管理系统DataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view1BindingSource
            // 
            this.view1BindingSource.DataMember = "view1";
            this.view1BindingSource.DataSource = this.职业介绍信息管理系统DataSet7;
            // 
            // view1TableAdapter
            // 
            this.view1TableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = WindowsFormsApp3.职业介绍信息管理系统DataSet7TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // view1_remain
            // 
            this.view1_remain.AutoGenerateColumns = false;
            this.view1_remain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.view1_remain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.view1_remain.DataSource = this.view1BindingSource;
            this.view1_remain.Location = new System.Drawing.Point(78, 64);
            this.view1_remain.Name = "view1_remain";
            this.view1_remain.RowTemplate.Height = 27;
            this.view1_remain.Size = new System.Drawing.Size(443, 220);
            this.view1_remain.TabIndex = 2;
            this.view1_remain.Visible = false;
            this.view1_remain.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.view1_remain_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "招聘编号";
            this.dataGridViewTextBoxColumn1.HeaderText = "招聘编号";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "单位编号";
            this.dataGridViewTextBoxColumn2.HeaderText = "单位编号";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "工资";
            this.dataGridViewTextBoxColumn3.HeaderText = "工资";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "岗位余量";
            this.dataGridViewTextBoxColumn4.HeaderText = "岗位余量";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // 职业介绍信息管理系统DataSet8
            // 
            this.职业介绍信息管理系统DataSet8.DataSetName = "职业介绍信息管理系统DataSet8";
            this.职业介绍信息管理系统DataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view2BindingSource
            // 
            this.view2BindingSource.DataMember = "view2";
            this.view2BindingSource.DataSource = this.职业介绍信息管理系统DataSet8;
            // 
            // view2TableAdapter
            // 
            this.view2TableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.Connection = null;
            this.tableAdapterManager2.UpdateOrder = WindowsFormsApp3.职业介绍信息管理系统DataSet8TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // view_moneyfromc
            // 
            this.view_moneyfromc.AutoGenerateColumns = false;
            this.view_moneyfromc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.view_moneyfromc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.view_moneyfromc.DataSource = this.view2BindingSource;
            this.view_moneyfromc.Location = new System.Drawing.Point(178, 64);
            this.view_moneyfromc.Name = "view_moneyfromc";
            this.view_moneyfromc.RowTemplate.Height = 27;
            this.view_moneyfromc.Size = new System.Drawing.Size(242, 220);
            this.view_moneyfromc.TabIndex = 5;
            this.view_moneyfromc.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "介绍人员编号";
            this.dataGridViewTextBoxColumn5.HeaderText = "介绍人员编号";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "C端业绩";
            this.dataGridViewTextBoxColumn6.HeaderText = "C端业绩";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // 职业介绍信息管理系统DataSet9
            // 
            this.职业介绍信息管理系统DataSet9.DataSetName = "职业介绍信息管理系统DataSet9";
            this.职业介绍信息管理系统DataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view3BindingSource
            // 
            this.view3BindingSource.DataMember = "view3";
            this.view3BindingSource.DataSource = this.职业介绍信息管理系统DataSet9;
            // 
            // view3TableAdapter
            // 
            this.view3TableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager3
            // 
            this.tableAdapterManager3.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager3.Connection = null;
            this.tableAdapterManager3.UpdateOrder = WindowsFormsApp3.职业介绍信息管理系统DataSet9TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // view_moneyfromb
            // 
            this.view_moneyfromb.AutoGenerateColumns = false;
            this.view_moneyfromb.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.view_moneyfromb.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.view_moneyfromb.DataSource = this.view3BindingSource;
            this.view_moneyfromb.Location = new System.Drawing.Point(178, 64);
            this.view_moneyfromb.Name = "view_moneyfromb";
            this.view_moneyfromb.RowTemplate.Height = 27;
            this.view_moneyfromb.Size = new System.Drawing.Size(245, 220);
            this.view_moneyfromb.TabIndex = 6;
            this.view_moneyfromb.Visible = false;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "介绍人员编号";
            this.dataGridViewTextBoxColumn7.HeaderText = "介绍人员编号";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "B端业绩";
            this.dataGridViewTextBoxColumn8.HeaderText = "B端业绩";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // 职业介绍信息管理系统DataSet10
            // 
            this.职业介绍信息管理系统DataSet10.DataSetName = "职业介绍信息管理系统DataSet10";
            this.职业介绍信息管理系统DataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view4BindingSource
            // 
            this.view4BindingSource.DataMember = "view4";
            this.view4BindingSource.DataSource = this.职业介绍信息管理系统DataSet10;
            // 
            // view4TableAdapter
            // 
            this.view4TableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager4
            // 
            this.tableAdapterManager4.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager4.Connection = null;
            this.tableAdapterManager4.UpdateOrder = WindowsFormsApp3.职业介绍信息管理系统DataSet10TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // view_company
            // 
            this.view_company.AutoGenerateColumns = false;
            this.view_company.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.view_company.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.view_company.DataSource = this.view4BindingSource;
            this.view_company.Location = new System.Drawing.Point(78, 64);
            this.view_company.Name = "view_company";
            this.view_company.RowTemplate.Height = 27;
            this.view_company.Size = new System.Drawing.Size(443, 220);
            this.view_company.TabIndex = 9;
            this.view_company.Visible = false;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "求职者编号";
            this.dataGridViewTextBoxColumn9.HeaderText = "求职者编号";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "求职者姓名";
            this.dataGridViewTextBoxColumn10.HeaderText = "求职者姓名";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "职业类型名";
            this.dataGridViewTextBoxColumn11.HeaderText = "职业类型名";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "单位名称";
            this.dataGridViewTextBoxColumn12.HeaderText = "单位名称";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // mainmenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 309);
            this.Controls.Add(this.view_company);
            this.Controls.Add(this.view_moneyfromb);
            this.Controls.Add(this.view_moneyfromc);
            this.Controls.Add(this.view1_remain);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "mainmenu";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.mainmenu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业信息BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view1_remain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_moneyfromc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_moneyfromb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.职业介绍信息管理系统DataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view4BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view_company)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem 职业信息管理ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem 职业信息ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem 用人单位ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem 职业分类ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem 求职信息管理ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem 求职者ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem 费用信息管理ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem 单位收费ToolStripMenuItem;
        private 职业介绍信息管理系统DataSet 职业介绍信息管理系统DataSet;
        private System.Windows.Forms.BindingSource 职业信息BindingSource;
        private 职业介绍信息管理系统DataSetTableAdapters.职业信息TableAdapter 职业信息TableAdapter;
        private 职业介绍信息管理系统DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ToolStripMenuItem 介绍人员ToolStripMenuItem;
        private System.Windows.Forms.Button button2;
        private 职业介绍信息管理系统DataSet7 职业介绍信息管理系统DataSet7;
        private System.Windows.Forms.BindingSource view1BindingSource;
        private 职业介绍信息管理系统DataSet7TableAdapters.view1TableAdapter view1TableAdapter;
        private 职业介绍信息管理系统DataSet7TableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView view1_remain;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private 职业介绍信息管理系统DataSet8 职业介绍信息管理系统DataSet8;
        private System.Windows.Forms.BindingSource view2BindingSource;
        private 职业介绍信息管理系统DataSet8TableAdapters.view2TableAdapter view2TableAdapter;
        private 职业介绍信息管理系统DataSet8TableAdapters.TableAdapterManager tableAdapterManager2;
        private System.Windows.Forms.DataGridView view_moneyfromc;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private 职业介绍信息管理系统DataSet9 职业介绍信息管理系统DataSet9;
        private System.Windows.Forms.BindingSource view3BindingSource;
        private 职业介绍信息管理系统DataSet9TableAdapters.view3TableAdapter view3TableAdapter;
        private 职业介绍信息管理系统DataSet9TableAdapters.TableAdapterManager tableAdapterManager3;
        private System.Windows.Forms.DataGridView view_moneyfromb;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private 职业介绍信息管理系统DataSet10 职业介绍信息管理系统DataSet10;
        private System.Windows.Forms.BindingSource view4BindingSource;
        private 职业介绍信息管理系统DataSet10TableAdapters.view4TableAdapter view4TableAdapter;
        private 职业介绍信息管理系统DataSet10TableAdapters.TableAdapterManager tableAdapterManager4;
        private System.Windows.Forms.DataGridView view_company;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.ToolStripMenuItem 一键查询工作岗位余量ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 输出每个应聘成功的求职者及供职的公司ToolStripMenuItem;
    }
}