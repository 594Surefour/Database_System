﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class mainmenu : Form
    {
        public mainmenu()
        {
            InitializeComponent();
        }

        public void mainmenu_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“职业介绍信息管理系统DataSet10.view4”中。您可以根据需要移动或删除它。
            this.view4TableAdapter.Fill(this.职业介绍信息管理系统DataSet10.view4);
            // TODO: 这行代码将数据加载到表“职业介绍信息管理系统DataSet9.view3”中。您可以根据需要移动或删除它。
            this.view3TableAdapter.Fill(this.职业介绍信息管理系统DataSet9.view3);
            // TODO: 这行代码将数据加载到表“职业介绍信息管理系统DataSet8.view2”中。您可以根据需要移动或删除它。
            this.view2TableAdapter.Fill(this.职业介绍信息管理系统DataSet8.view2);
            // TODO: 这行代码将数据加载到表“职业介绍信息管理系统DataSet7.view1”中。您可以根据需要移动或删除它。
            this.view1TableAdapter.Fill(this.职业介绍信息管理系统DataSet7.view1);
            // TODO: 这行代码将数据加载到表“职业介绍信息管理系统DataSet.职业信息”中。您可以根据需要移动或删除它。
            this.职业信息TableAdapter.Fill(this.职业介绍信息管理系统DataSet.职业信息);


        }
        private void mainmenu_closing(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void 职业信息管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public void 求职信息管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public void 费用信息管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        public void 费用信息管理ToolStripMenuIte(object sender, EventArgs e)
        {

        }
       
        public void 求职者ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
        }

        public void 单位收费ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();
            form9.Show();
        }

        public void 职业信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 Form3 = new Form3();
            Form3.Show();
        }

        public void 用人单位ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 Form4 = new Form4();
            Form4.Show();
        }

        public void 职业分类ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
        }

        private void 职业信息BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.职业信息BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.职业介绍信息管理系统DataSet);

        }

        private void 介绍人员ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.Show();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void button1_Click_1(object sender, EventArgs e)
        {
            view1_remain.Visible = true;
            view_moneyfromc.Visible = view_moneyfromb.Visible = view_company.Visible = false;
        }

        public void button3_Click(object sender, EventArgs e)
        {
            view_moneyfromc.Visible = true;
            view1_remain.Visible = view_moneyfromb.Visible = view_company.Visible = false;
        }

        public void button4_Click(object sender, EventArgs e)
        {
            view_moneyfromb.Visible = true;
            view1_remain.Visible = view_moneyfromc.Visible = view_company.Visible = false;
        }

        public void button5_Click(object sender, EventArgs e)
        {
            view_company.Visible = true;
            view1_remain.Visible = view_moneyfromc.Visible = view_moneyfromb.Visible =  false;
        }

        private void 一键查询工作岗位余量ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            view1_remain.Visible = true;
            view_moneyfromc.Visible = view_moneyfromb.Visible = view_company.Visible = false;
        }

        private void 一键查询中介人员从求职者处取得的中介费收入ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            view_moneyfromc.Visible = true;
            view1_remain.Visible = view_moneyfromb.Visible = view_company.Visible = false;
        }

        private void 一键查询中介人员从企业处取得的中介费收入ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            view_moneyfromb.Visible = true;
            view1_remain.Visible = view_moneyfromc.Visible = view_company.Visible = false;
        }

        private void 输出每个应聘成功的求职者及供职的公司ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            view_company.Visible = true;
            view1_remain.Visible = view_moneyfromc.Visible = view_moneyfromb.Visible = false;
        }

        private void view1_remain_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
