﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void 职业信息BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.职业信息BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.职业介绍信息管理系统DataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“职业介绍信息管理系统DataSet.职业信息”中。您可以根据需要移动或删除它。
            this.职业信息TableAdapter.Fill(this.职业介绍信息管理系统DataSet.职业信息);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                职业信息BindingSource.Filter = "招聘编号 ='" + textBox1.Text.Trim() + "'";
        }
    }
}
