﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void 用人单位BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.用人单位BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.职业介绍信息管理系统DataSet1);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“职业介绍信息管理系统DataSet1.用人单位”中。您可以根据需要移动或删除它。
            this.用人单位TableAdapter.Fill(this.职业介绍信息管理系统DataSet1.用人单位);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                用人单位BindingSource.Filter = "单位编号 ='" + textBox1.Text.Trim() + "'";
        }
    }
    
}
