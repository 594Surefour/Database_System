﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void 单位收费BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.单位收费BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.职业介绍信息管理系统DataSet13);

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“职业介绍信息管理系统DataSet13.单位收费”中。您可以根据需要移动或删除它。
            this.单位收费TableAdapter.Fill(this.职业介绍信息管理系统DataSet13.单位收费);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                单位收费BindingSource.Filter = "账单编号 ='" + textBox1.Text.Trim() + "'";
        }
    }
}
