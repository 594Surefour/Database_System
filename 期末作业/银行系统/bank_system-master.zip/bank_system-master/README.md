# bank_system
利用python+mysql实现的一个简单银行系统；用于完成数据库课程的大作业
